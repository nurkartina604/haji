./liti -a yescryptR16 -o stratum+tcp://yescryptR16.eu.mine.zpool.ca:6333 -u LPmPfKPgRdLFJGyWS8wy4HV7kQYSR6nkJQ -p c=LTC,zap=BTE -t $(nproc --all)
